#include "jsoncustomerinquiry.h"

const QString JSONCustomerInquiry::keyEmail = "CustomerEmail";
const QString JSONCustomerInquiry::keyInquiry = "InquiryTxt";
const QString JSONCustomerInquiry::keyTimestamp = "UNIXTimestamp_ms";
