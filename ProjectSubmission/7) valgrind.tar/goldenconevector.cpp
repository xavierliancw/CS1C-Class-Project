#include "goldenconevector.h"
using namespace std;

int main()
{
	GoldenConeVector<int> vec1;
	int x = 5;

	vec1.push_back(1);
	vec1.push_back(2);
	vec1.push_back(3);
	vec1.push_back(4);
	vec1.push_back(5);
	vec1.push_back(6);
	vec1.push_back(-11);

	cout << endl;

	vec1.print();

	cout << endl;

	vec1.resize(50);
	try
	{
		x = vec1[49];
	}
	catch (...)
	{
		cout << "The data attempted to access with [] is uninitialized";
	}
	cout << endl;
	vec1.printinfo();
	cout << endl;
	try
	{
		x = vec1[1];
	}
	catch (...)
	{
		cout << "The data attempted to access with [] is uninitialized";
	}
	cout << x << endl;
	vec1.reserve(69);
	vec1.insert(vec1.begin(), 626);

	cout << endl;

	vec1.print();

	cout << endl;

	x = vec1.capacity();

	cout << x << endl;

	vec1.erase(vec1.end());

	cout << endl;

	vec1.print();

	cout << endl;

	GoldenConeVector<int> vec2 = vec1;

	cout << endl;
	vec2.print();
	cout << endl;

	GoldenConeVector<double> vec3;
	double y = 5;

	vec3.push_back(7.7);
	vec3.push_back(9.32);
	vec3.push_back(4.67);
	vec3.push_back(5.627);
	vec3.push_back(9.9789);
	vec3.push_back(5.55);
	vec3.push_back(-11.420);

	cout << endl;

	vec3.print();

	cout << endl;

	vec3.resize(13);
	try {
		y = vec3[15];
	}
	catch (...)
	{
		cout << "The data attempted to access with [] is uninitialized";
	}
	cout << endl;
	vec3.printinfo();
	cout << endl;
	try {
		y = vec3[1];
	}
	catch (...)
	{
		cout << "The data attempted to access with [] is uninitialized";
	}
	cout << y << endl;
	vec3.reserve(69);
	vec3.insert(vec3.begin(), 420.39);

	cout << endl;

	vec3.print();

	cout << endl;

	y = vec3.capacity();

	cout << y << endl;

	vec3.erase(vec3.end());

	cout << endl;

	vec3.print();

	cout << endl;

	GoldenConeVector<double> vec4;
	vec4 = vec3;

	cout << endl;
	vec4.print();
	cout << endl;

	return 0;
}