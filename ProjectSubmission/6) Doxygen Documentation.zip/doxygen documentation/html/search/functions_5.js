var searchData=
[
  ['finishediting',['finishEditing',['../class_v_m_editor_vertices.html#a3dafad61c61cfd7b90d2e1651daa79be',1,'VMEditorVertices']]],
  ['fromjson',['fromJSON',['../struct_j_s_o_n_customer_inquiry.html#a9b0e309ca1a6e1794f7f3473d42a7d2b',1,'JSONCustomerInquiry::fromJSON()'],['../struct_j_s_o_n_shape.html#ae3db5716fcc492a8c2628d77ea04d454',1,'JSONShape::fromJSON()'],['../struct_j_s_o_n_testimonial.html#a8b6b42ef202b1566b27b0d42a3074650',1,'JSONTestimonial::fromJSON()']]]
];
