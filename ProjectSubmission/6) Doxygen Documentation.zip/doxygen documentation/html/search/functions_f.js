var searchData=
[
  ['theshared',['theShared',['../class_gimme.html#a919dd9390c493f42f847039d024f9f80',1,'Gimme']]],
  ['tojson',['toJSON',['../struct_j_s_o_n_customer_inquiry.html#ac470def01a19da61aec37311cb2ed438',1,'JSONCustomerInquiry::toJSON()'],['../struct_j_s_o_n_shape.html#a38bb052953becd55f29000f819aa314d',1,'JSONShape::toJSON()'],['../struct_j_s_o_n_testimonial.html#a9fcbce44173627482821d8912f8531d5',1,'JSONTestimonial::toJSON()']]]
];
