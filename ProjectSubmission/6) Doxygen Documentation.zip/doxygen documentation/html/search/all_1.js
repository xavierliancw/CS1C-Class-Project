var searchData=
[
  ['begin',['begin',['../class_golden_cone_vector.html#aeb123e6db4c356b66754ee6e2e813935',1,'GoldenConeVector']]],
  ['brush',['brush',['../class_i_shape.html#a3827e9f0c3c88331ceaa3bb9b00f7073',1,'IShape']]]
];
