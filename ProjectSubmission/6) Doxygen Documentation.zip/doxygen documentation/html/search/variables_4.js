var searchData=
[
  ['id',['id',['../class_i_shape.html#a6ff2d631831c1079b88eeebc8ac65bb0',1,'IShape']]],
  ['inquirytxt',['inquiryTxt',['../struct_d_t_o_customer_inquiry.html#a22e1c2babfe2efd005d4e9e048a13f89',1,'DTOCustomerInquiry']]]
];
