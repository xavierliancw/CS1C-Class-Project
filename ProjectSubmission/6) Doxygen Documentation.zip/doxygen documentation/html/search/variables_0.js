var searchData=
[
  ['brush',['brush',['../class_i_shape.html#a3827e9f0c3c88331ceaa3bb9b00f7073',1,'IShape']]]
];
