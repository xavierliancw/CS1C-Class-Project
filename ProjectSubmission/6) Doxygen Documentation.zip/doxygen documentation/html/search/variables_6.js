var searchData=
[
  ['savebttxt',['saveBtTxt',['../class_v_m_testimonial_create.html#af2b4326b5a7abd3f815df754880ae2d5',1,'VMTestimonialCreate']]],
  ['successdonebttxt',['successDoneBtTxt',['../class_v_m_testimonial_create.html#afe5812a327160651286af17f65c62416',1,'VMTestimonialCreate']]],
  ['successmsg',['successMsg',['../class_v_m_testimonial_create.html#ad496e34b013e7d4ee879f8bc8eaa434b',1,'VMTestimonialCreate']]]
];
