var searchData=
[
  ['displayname',['displayName',['../struct_d_t_o_testimonial.html#a921b43f474c61d95bf567b35923e9054',1,'DTOTestimonial']]]
];
