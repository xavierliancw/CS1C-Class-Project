var searchData=
[
  ['filenameforsavedcustomerinquiries',['fileNameForSavedCustomerInquiries',['../class_gimme.html#aa9b6e0a689535736ab697a54e40ef5fc',1,'Gimme']]],
  ['filenameforsavedgraphicscanvas',['fileNameForSavedGraphicsCanvas',['../class_gimme.html#a75f442cedd5b873cc9982a812ac56c8f',1,'Gimme']]],
  ['filenamefortestimonials',['fileNameForTestimonials',['../class_gimme.html#aa9fd95a9aa3dc9734d4f8357c4620efa',1,'Gimme']]],
  ['frame',['frame',['../class_shape_ellipse.html#ac9feb0571e6f658866ab142643230081',1,'ShapeEllipse::frame()'],['../class_shape_rect.html#a238099eccd2cd32a7e82cb1719b36b51',1,'ShapeRect::frame()']]]
];
