var searchData=
[
  ['theshared',['theShared',['../class_gimme.html#a919dd9390c493f42f847039d024f9f80',1,'Gimme']]],
  ['timestamp_5funix',['timestamp_unix',['../struct_d_t_o_customer_inquiry.html#a77170a12cf54b579b1fe6bb707f325f3',1,'DTOCustomerInquiry::timestamp_unix()'],['../struct_d_t_o_testimonial.html#a66672c5d252a46d247997e9e67c600c3',1,'DTOTestimonial::timestamp_unix()']]],
  ['tojson',['toJSON',['../struct_j_s_o_n_customer_inquiry.html#ac470def01a19da61aec37311cb2ed438',1,'JSONCustomerInquiry::toJSON()'],['../struct_j_s_o_n_shape.html#a38bb052953becd55f29000f819aa314d',1,'JSONShape::toJSON()'],['../struct_j_s_o_n_testimonial.html#a9fcbce44173627482821d8912f8531d5',1,'JSONTestimonial::toJSON()']]],
  ['txt',['txt',['../struct_d_t_o_testimonial.html#a2fe975367ddcb0e51ff4834ecf40a503',1,'DTOTestimonial']]]
];
