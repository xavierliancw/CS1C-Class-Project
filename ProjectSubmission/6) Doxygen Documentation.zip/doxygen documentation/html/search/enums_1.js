var searchData=
[
  ['screensinwinmain',['ScreensInWINMain',['../class_w_i_n_main.html#a2ffef4f00d863ba1ff8a1cc725a6b1f7',1,'WINMain']]],
  ['shapetype',['ShapeType',['../class_i_shape.html#a8f50993477b5ddb44c0547ef3d547cdc',1,'IShape']]]
];
