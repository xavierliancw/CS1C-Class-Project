var searchData=
[
  ['filenameforsavedcustomerinquiries',['fileNameForSavedCustomerInquiries',['../class_gimme.html#aa9b6e0a689535736ab697a54e40ef5fc',1,'Gimme']]],
  ['filenameforsavedgraphicscanvas',['fileNameForSavedGraphicsCanvas',['../class_gimme.html#a75f442cedd5b873cc9982a812ac56c8f',1,'Gimme']]],
  ['filenamefortestimonials',['fileNameForTestimonials',['../class_gimme.html#aa9fd95a9aa3dc9734d4f8357c4620efa',1,'Gimme']]],
  ['finishediting',['finishEditing',['../class_v_m_editor_vertices.html#a3dafad61c61cfd7b90d2e1651daa79be',1,'VMEditorVertices']]],
  ['frame',['frame',['../class_shape_ellipse.html#ac9feb0571e6f658866ab142643230081',1,'ShapeEllipse::frame()'],['../class_shape_rect.html#a238099eccd2cd32a7e82cb1719b36b51',1,'ShapeRect::frame()']]],
  ['fromjson',['fromJSON',['../struct_j_s_o_n_customer_inquiry.html#a9b0e309ca1a6e1794f7f3473d42a7d2b',1,'JSONCustomerInquiry::fromJSON()'],['../struct_j_s_o_n_shape.html#ae3db5716fcc492a8c2628d77ea04d454',1,'JSONShape::fromJSON()'],['../struct_j_s_o_n_testimonial.html#a8b6b42ef202b1566b27b0d42a3074650',1,'JSONTestimonial::fromJSON()']]]
];
