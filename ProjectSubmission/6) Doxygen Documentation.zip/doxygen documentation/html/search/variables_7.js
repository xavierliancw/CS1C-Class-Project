var searchData=
[
  ['timestamp_5funix',['timestamp_unix',['../struct_d_t_o_customer_inquiry.html#a77170a12cf54b579b1fe6bb707f325f3',1,'DTOCustomerInquiry::timestamp_unix()'],['../struct_d_t_o_testimonial.html#a66672c5d252a46d247997e9e67c600c3',1,'DTOTestimonial::timestamp_unix()']]],
  ['txt',['txt',['../struct_d_t_o_testimonial.html#a2fe975367ddcb0e51ff4834ecf40a503',1,'DTOTestimonial']]]
];
